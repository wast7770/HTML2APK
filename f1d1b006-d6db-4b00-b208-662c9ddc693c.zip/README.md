# TESTE

Projeto Android gerado pelo HTML2APK (Cordova).

## Por que não veio um .apk pronto?
Um navegador não tem acesso ao Android SDK nem ao Gradle — nenhuma ferramenta
rodando 100% em JavaScript no navegador consegue compilar um .apk binário de
verdade. Este ZIP contém o projeto Android completo e pronto para compilar.

## Como gerar o APK real sem usar um PC
1. Extraia este ZIP.
2. Crie um repositório novo no GitHub (dá pra fazer pelo app ou site, no celular).
3. Envie todos os arquivos extraídos para esse repositório.
4. Abra a aba "Actions" do repositório: o workflow em
   .github/workflows/build-apk.yml roda sozinho e compila o APK na nuvem.
5. Quando o build terminar (ícone verde), abra o resultado e baixe o
   artifact com o .apk — pronto pra instalar no Android.

## Estrutura
- config.xml — configuração do app (Cordova)
- AndroidManifest.xml — manifest Android gerado
- build.gradle — script de build do módulo app
- www/ — seu projeto HTML/CSS/JS original
- res/icon, res/screen — ícones e splash gerados
- .github/workflows/build-apk.yml — build automático na nuvem
